const songList = [
  { title: "Shape of You", artist: "Ed Sheeran" },
  { title: "Blinding Lights", artist: "The Weeknd" },
  { title: "Levitating", artist: "Dua Lipa" },
  { title: "Save Your Tears", artist: "The Weeknd" },
  { title: "Peaches", artist: "Justin Bieber" },
  { title: "Stay", artist: "Justin Bieber & The Kid LAROI" },
  { title: "Watermelon Sugar", artist: "Harry Styles" },
  { title: "Drivers License", artist: "Olivia Rodrigo" },
  { title: "Good 4 U", artist: "Olivia Rodrigo" },
  { title: "Someone Like You", artist: "Adele" },
];